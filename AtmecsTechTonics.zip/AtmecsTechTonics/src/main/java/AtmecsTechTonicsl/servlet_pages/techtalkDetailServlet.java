package AtmecsTechTonicsl.servlet_pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;







import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AtmecsTechTonics.dao.tecktalkdao;
import AtmecsTechTonics.pojos.Techtalk;





@WebServlet("/techtalk")
public class techtalkDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	tecktalkdao dao;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try {
			PrintWriter pw = response.getWriter();
			dao=new tecktalkdao();

			ArrayList<Techtalk> l1 = dao.getTechTalkDetailDao();
			System.out.println(l1);
			pw.print("<h3 align='center'>****techtalk dtls*** <br/></br></br></br>");
			pw.print("</h3><center>");
			pw.print("<table border=1>");
			pw.print("<tr><th>Date</th><th>Name</th><th>topics</th></tr>");
			for (Techtalk e : l1) {
				
				pw.print("<tr><td>");
				pw.print(e.getDate() + "</td>");
				//pw.print("<th>firstName</th>");
				pw.print("<td>");
			
				pw.print(e.getName()+ "</td>");
				//pw.print("<th>lastname</th>");
				pw.print("<td>");
				
				pw.print(e.getTopic() + "</td>");
				pw.print("<td><button>delete</button></td>");
				pw.print("<td><button>update</button></td></tr>");
				
			
				
				
			}
			pw.print("</table>");
			pw.print("</center>");
		
			pw.print("<a href='atmecswelome.jsp'>Back to welcome page</a>");
		} catch (Exception e) {
			throw new ServletException("err in do-get", e);
		}

	}

}
