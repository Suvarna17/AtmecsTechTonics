package AtmecsTechTonicsl.servlet_pages;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AtmecsTechTonics.dao.Employeedao;

/**
 * Servlet implementation class loginServlet1
 */
@WebServlet("/loginSer")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 Employeedao dao;
   /* @Override
    public void init()
    {
    	
    System.out.println("in init");
    }*/

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	System.out.println("in login form");
		try {
			 dao = new Employeedao();
			String uname=request.getParameter("Username");
			String pwd=request.getParameter("Password");
			
		/*	if(uname=="admin" && pwd=="admin")
			{
				 response.sendRedirect("./techtalk.jsp");
			}*/
			boolean result=dao.validateUser(uname, pwd);
			
			if(result==true)
			{
				 response.sendRedirect("./techtalk");
			}
			else
			{    
				 response.sendRedirect("./index.jsp");
			}
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
