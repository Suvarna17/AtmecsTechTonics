package AtmecsTechTonicsl.servlet_pages;

import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AtmecsTechTonics.dao.Employeedao;
import AtmecsTechTonics.pojos.Employee;





/**
 * Servlet implementation class registerservlet
 */
@WebServlet("/registerser")
public class registerservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private Employeedao dao;
    /**
     * @throws Exception 
     * @see HttpServlet#HttpServlet()
     */
    public registerservlet() throws Exception {
        
        
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
	    
	        System.out.println("In the registration Servlet");
	      
		    	AtmecsTechTonics.dao.Employeedao dao;
		        System.out.println("In the registration Servlet");
	
		      	String user=request.getParameter("username");
		      	String pwd=request.getParameter("pwd");
		      	String email=request.getParameter("email");
		      	Employee em=new Employee(user, pwd, email);
		      	dao=new Employeedao();
		      	if(dao.registerEmployee(em)!=null)
		      	{

					 response.sendRedirect("./index.jsp");
		      	}
		        //response.sendRedirect("welcome.jsp");        
		    } catch (Throwable exc)
		    {
		        System.out.println(exc);
		    }
		
	      

}
}
