/*package AtmecsTechTonics.dao;

import static AtmecsTechTonics.dao.DBUtils.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class Admindao {
	private Connection cn;
	private PreparedStatement pst1,pst2;
	
	
	public Admindao() throws Exception
	{ 	
		cn=getConnection();
		//cn=getConnection();
		String query=" select * from admin where username=? and password=?";
	
		
		pst1=cn.prepareStatement(query);
		
		//pst1.setString(arg0, arg1);
	
}
}
*/