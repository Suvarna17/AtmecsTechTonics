package AtmecsTechTonics.dao;

import static AtmecsTechTonics.dao.DBUtils.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import AtmecsTechTonics.pojos.Techtalk;





public class tecktalkdao {
	private Connection cn;
	private PreparedStatement pst1,pst2;
	
	
	public tecktalkdao() throws Exception
	{ 	cn=getConnection();
		String query=" select * from techtalks";
		pst1=cn.prepareStatement(query);
			pst2=cn.prepareStatement("insert into techtalks values(?,?,?)");
		
	}
	
	public void cleanUp() throws Exception {
		System.out.println("in clean-up");
		{
			if (pst1 != null)
				pst1.close();
			
		}
}
	
	public ArrayList<Techtalk> getTechTalkDetailDao() throws SQLException
	{
		ArrayList<Techtalk> al=new ArrayList<Techtalk>();
		try
		{
			ResultSet rs=pst1.executeQuery();
			while(rs.next())
			{
				al.add(new Techtalk(rs.getString(1),rs.getString(2),rs.getString(3)));
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return al;
      }
	
	public int addTechTalk(String date,String name ,String topics) throws Exception{
		System.out.println("in dao createEmployee");
		
	
		pst2.setString(1,date);
		pst2.setString(2,name);
		pst2.setString(3, topics);
		int rst=pst2.executeUpdate();
		System.out.println("in add techtalk");
		if(rst==1)
		return 1;
		return 0;
	}
	
}

	