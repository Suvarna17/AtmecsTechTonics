package AtmecsTechTonics.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import AtmecsTechTonics.pojos.Employee;
import static AtmecsTechTonics.dao.DBUtils.getConnection;





public class Employeedao {
	private Connection cn;
	private PreparedStatement pst1,pst2,pst3;
	
	
	public Employeedao() throws Exception
	{ 	
		cn=getConnection();
		//cn=getConnection();
		String query=" select * from employeedetails where username=? and pwd=?";
	String sql="insert into employeedetails values(?,?,?)";
	String sql1="delete form techtalk where name=? ";
		
		pst1=cn.prepareStatement(query);
		pst2 = cn.prepareStatement(sql);
		//pst1.setString(arg0, arg1);
		pst3=cn.prepareStatement(sql1);
	}
	
	public void cleanUp() throws Exception {
		System.out.println("in clean-up");
		{
			if (pst1 != null)
				pst1.close();
			if (pst2 != null)
				pst2.close();
			if (pst3 != null)
				pst3.close();
		}
}
	
	public boolean validateUser(String username,String password) throws SQLException
	{
		
		String str="failed to login";
		pst1.setString(1, username);
		pst1.setString(2, password);
		try{
			ResultSet rst = pst1.executeQuery();
			if (rst.next()){
				System.out.println("login success");
				return true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println(str);
		return false;
}
	public String registerEmployee(Employee e)
	{
		String str="failed to register";
	
	try{
		pst2.setString(1, e.getUsername());
		pst2.setString(2, e.getPwd());
		pst2.setString(3, e.getEmail());
	
		int updateCount = pst2.executeUpdate();
		if (updateCount == 1)
			
			System.out.println("registration success");
		else 
			System.out.println("registration fail success"); 
		
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
	return str;
}
		
	}
