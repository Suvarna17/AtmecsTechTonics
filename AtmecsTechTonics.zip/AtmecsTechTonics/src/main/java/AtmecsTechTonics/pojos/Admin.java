package AtmecsTechTonics.pojos;

public class Admin {

}
