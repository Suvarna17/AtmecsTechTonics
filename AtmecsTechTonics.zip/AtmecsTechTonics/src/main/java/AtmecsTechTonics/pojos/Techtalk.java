package AtmecsTechTonics.pojos;

public class Techtalk {

	private String date;
	private String name;
	private String topic;
	
	public Techtalk() {
		super();
	}


	public Techtalk(String date, String name, String topic) {
		super();
		this.date = date;
		this.name = name;
		this.topic = topic;
	}

	
	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getTopic() {
		return topic;
	}


	public void setTopic(String topic) {
		this.topic = topic;
	}




	@Override
	public String toString() {
		return "Techtalk [date=" + date + ", name=" + name + ", topic=" + topic
				+ "]";
	}

}