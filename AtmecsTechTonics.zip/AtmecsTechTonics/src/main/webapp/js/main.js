jQuery(document).ready(function($) {

    'use strict';

    /*============================================*/
    //             jQuery custom
    /*============================================*/

    /*=== app-screenshot ====*/
    $(".app-screenshot").owlCarousel({
        autoplay: true,
        loop: true,
        nav: true,
        margin: 20,
        navText: ['<i class="lnr lnr-chevron-left"></i>', '<i class="lnr lnr-chevron-right"></i>'],
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
                nav: true
            },
            600:{
                items:3,
                nav: true
            },
            1000:{
                items:4,
                loop:true,
                nav: true,
            }
        }
    });

    /*=== testimonial slide ====*/
    $(".testimonial-slide").owlCarousel({
        autoplay: true,
        loop:true,
        margin:10,
        nav: true,
        navText: ['<i class="lnr lnr-arrow-left"></i>', '<i class="lnr lnr-arrow-right"></i>'],
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
                nav:true
            },
            600:{
                items:2,
                nav:true
            },
            1000:{
                items:2,
                nav:true,
                loop:true
            }
        }
    });


    /*=== app-skill ====*/
    jQuery('.single').each(function(){
        jQuery(this).find('.single-bar').animate({
            width:jQuery(this).attr('data-percent')
        },1000);
    });


    /*=== stellar ====*/
    $.stellar({
        responsive: false,
        horizontalScrolling: false,
    });


    /*=== smooth scroll ====*/
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('.back-scroll').fadeIn();
        } else {
            $('.back-scroll').fadeOut();
        }
    });


    /*=== wow scroll ====*/
    new WOW().init();


    /*=== fitvids - responsive video ====*/
    $("#responsive-video").fitVids();


    /*=== Scroll script ====*/
    //jQuery for page scrolling feature - requires jQuery Easing plugin
    $(function() {
        $('.section-scroll').bind('click', function(event) {
            var $anchor = $(this);
            $('html, body').stop().animate({
                scrollTop: $($anchor.attr('href')).offset().top - 69
            }, 1000);
            event.preventDefault();
        });
    });


    /* services read more section */

    $('.services-btn').click(function(){
        jQuery('#services-content').show();
        jQuery('#services-menu').hide();
        jQuery('.services-para').hide();
        activaTab($(this).attr('name'));
        jQuery('#resources-content').addClass('animated fadeIn');
    });

    jQuery("#back_to_Services").click(function(event) {
        event.preventDefault();
        jQuery('.services-para').show();
        jQuery('#services-content').hide();
        jQuery('#services-menu').show();
        jQuery('#services-menu').addClass('animated fadeIn');

    });
    $('#services-topmenu').click(function(){
        jQuery('#services-content').hide();
        jQuery('#services-menu').show();
        jQuery('.services-para').show();
    })
    function activaTab(tab){
        $('.nav-pills a[href="#' + tab + '"]').tab('show');
    };

    /*   service read more end */

    /* About us read more start */

    $('.about_us_more').click(function(){
        jQuery('#aboutus-content').show();
        jQuery('.aboutus-menu').hide();
    });
    $('#about-topmenu').click(function(){
        jQuery('#aboutus-content').hide();
        jQuery('.aboutus-menu').show();
    })

    jQuery("#back_to_about").click(function(event) {
        event.preventDefault();
        jQuery('#aboutus-content').hide();
        jQuery('.aboutus-menu').show();
        jQuery('.aboutus-menu').addClass('animated fadeIn');

    });
    $('.panel-collapse').on('show.bs.collapse', function () {
        $(this).parent('.panel').find('.fa-minus').show();
        $(this).parent('.panel').find('.fa-plus').hide();
    })
    $('.panel-collapse').on('hide.bs.collapse', function () {
        $(this).parent('.panel').find('.fa-minus').hide();
        $(this).parent('.panel').find('.fa-plus').show();
    });
    /*  About us read more end */

    $('#submit_button').click(function(){
        if($('#name').val()=='') {
            $('.form-message').show();
            $('.form-message').html('Please enter name.');
            return;
        } else if($('#email').val()=='') {
            $('.form-message').show();
            $('.form-message').html('Please enter email.');
            return;
        } else if($('#phone').val()=='') {
            $('.form-message').show();
            $('.form-message').html('Please enter phone.');
            return;
        } else if($('#message').val()=='') {
            $('.form-message').show();
            $('.form-message').html('Please enter message or comments.');
            return;
        }
        //$('#contactform').submit();
        // {'name':$('#name').val(), 'email':$('#email').val(), 'phone':$('#phone').val(), 'message':$('#message').val()}
        $.ajax({
            type: 'POST',
            url: 'http://atmecs.com/send_form_email.php',
            data: $('#contactform').serialize(),
            success: function(data) {
                $('.form-message').show();
                if (data.indexOf('retry')>0) {
                    $('.form-message').html('Due to some issue, we could not receive your details, Please send mail to info@atmecs.com').fadeOut(5000);
                } else {
                    $('.form-message').html(data).fadeOut(5000); //'Your messsage has been sent successfully. We will get back to you shortly.'+
                }
                $('.form-control').val('');
            },
            error: function(data) {
                $('.form-message').show();
                $('.form-message').html('Server error.'+data);
            }
        });

    });

    /* collapse nav bar in mobile */

    $('.section-scroll').click(function(){
        $('#navbar-top').removeClass('in')
    });
});


/*jQuery(document).ready(function(e) {

 e(window).ready(function() {*/
/*$(".flexslider").flexslider({
    animation: "fade",
    animationLoop: true,
    slideshow: true,
    slideshowSpeed: 3000,
    animationSpeed: 800,
    pauseOnHover: true,
    pauseOnAction: true,
    controlNav: false,
    touch: false,
    directionNav: true,
    controlsContainer: ".flex-container",
    start: function(t) {
        var n = $(".slider-1 .flex-active-slide h2").data("toptitle");
        var nl = $(".slider-1 .flex-active-slide h2").data("lefttitle");
        var i = $(".slider-1 .flex-active-slide p").data("bottomtext");
        var il = $(".slider-1 .flex-active-slide p").data("lefttitle");
        var box = $(".slider-1 .flex-active-slide .innertextbox").data("toptitle");
        if($(".flex-active-slide").attr('class') == 'slide1 flex-active-slide'){
            var lowerText = ($(".flex-active-slide h2").height() ) + 90 + 'px'
        }
        else{
            var lowerText = ($(".flex-active-slide h2").height() ) + 110 + 'px'
        }
        $(".slider-1 .flex-active-slide").find("h2").animate({
            left: nl,
            top: n,
            opacity: "1"
        }, 1500);
        $(".slider-1 .flex-active-slide").find("p").animate({
            left: il,
            top: lowerText,
            opacity: "1"
        }, 1500);
        $(".slider-1 .flex-active-slide .innertextbox").animate({
            left: nl,
            top: box,
            opacity: "1"
        }, 1500);

        t.removeClass("loading")
    },
    before: function(t) {

        $(".slider-1 .flex-active-slide").find("h2").animate({
            left: "0",
            top: "-100%",
            opacity: "0"
        }, 1500);
        $(".slider-1 .flex-active-slide").find("p").animate({
            left: "0",
            bottom: "-50%",
            opacity: "0"
        }, 1500);

    },
    after: function(t) {
        var n = $(".slider-1 .flex-active-slide h2").data("toptitle");
        var nl = $(".slider-1 .flex-active-slide h2").data("lefttitle");
        var i = $(".slider-1 .flex-active-slide p").data("bottomtext");
        var il = $(".slider-1 .flex-active-slide p").data("lefttitle");
       // var lowerText = ($(".flex-active-slide h2").height() )  + 110 + 'px'

        if($(".flex-active-slide").attr('class') == 'slide1 flex-active-slide'){
            var lowerText = ($(".flex-active-slide h2").height() ) + 90 + 'px'
        }
        else{
            var lowerText = ($(".flex-active-slide h2").height() ) + 110 + 'px'
        }

        var box = $(".slider-1 .flex-active-slide .innertextbox").data("toptitle");
        $(".slider-1 .flex-active-slide").find("h2").animate({
            left: nl,
            top: n,
            opacity: "1"
        }, 1500);
        $(".slider-1 .flex-active-slide").find("p").animate({
            left: il,
            top: lowerText,
            opacity: "1"
        }, 1500);
        $(".slider-1 .flex-active-slide .innertextbox").animate({
            left: nl,
            top: box,
            opacity: "1"
        }, 1500);

    }
});*/
$('.slider-carousel').owlCarousel({
    loop:true,
    margin:10,
    items: 1,
    autoplay: true,
    nav:true,
    dots: true,
    // navText: ["<img src='images/left-arrow.png") %>'>","<img src='<%= asset_path("new_images/right-arrow.png") %>'>"],
    navText : ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
    autoplayTimeout: 3000

});

$('.casestudy-carousel').owlCarousel({
    items : 1,
    loop  : true,
    responsiveClass:true,
    margin : 30,
    nav    : true,
    smartSpeed :900,
    navText : ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"]

});
$('.news-events-carousel').owlCarousel({
    items : 1,
    loop  : true,
    responsiveClass:true,
    margin : 30,
    nav    : true,
    smartSpeed :900,
    navText : ["<img src='images/left-chevron.png'>","<img src='images/right-chevron.png'>"]

});
/*    });

 });*/

/*
 $(window).bind('resize', function() {

 var slider = $('.slider-1').data('flexslider');
 slider.resize();
 });*/

/*
 $(window).bind('resize', function() {
 var n = $(".slider-1 .flex-active-slide h2").data("toptitle");
 var nl = $(".slider-1 .flex-active-slide h2").data("lefttitle");
 var i = $(".slider-1 .flex-active-slide p").data("bottomtext");
 var il = $(".slider-1 .flex-active-slide p").data("lefttitle");
 var box = $(".slider-1 .flex-active-slide .innertextbox").data("toptitle");


 var lowerText = ($(".flex-active-slide h2").height() ) + 110 + 'px'
 // alert(lowerText)
 //  alert($(".flex-active-slide h2").height() )
 $(".slider-1 .flex-active-slide").find("h2").animate({
 left: nl,
 top: n,
 opacity: "1"
 }, 1500);
 $(".slider-1 .flex-active-slide").find("p").animate({
 left: il,
 top: lowerText,
 opacity: "1"
 }, 1500);
 $(".slider-1 .flex-active-slide .innertextbox").animate({
 left: nl,
 top: box,
 opacity: "1"
 }, 1500);

 });*/
